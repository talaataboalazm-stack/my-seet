// Cloudflare Worker (مجاني): يستقبل طلب الإدارة ويرسل إشعار FCM لأجهزة العميل.
// الأسرار المطلوبة (Settings → Variables and Secrets):
//   SERVICE_ACCOUNT : محتوى ملف مفتاح الخدمة من Firebase (JSON كامل)
//   ADMIN_EMAILS    : بريد الإدارة (يمكن أكثر من واحد مفصولة بفاصلة)

const JWK_URL = "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com";
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

const enc = new TextEncoder();
const b64u = (buf) => btoa(String.fromCharCode(...new Uint8Array(buf))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
const fromB64u = (s) => { s = s.replace(/-/g, "+").replace(/_/g, "/"); while (s.length % 4) s += "="; return Uint8Array.from(atob(s), (c) => c.charCodeAt(0)); };
const json = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json", ...CORS } });

let jwkCache = null;
async function getJwks() {
  if (jwkCache && jwkCache.exp > Date.now()) return jwkCache.keys;
  const r = await fetch(JWK_URL);
  const j = await r.json();
  jwkCache = { keys: j.keys, exp: Date.now() + 3600e3 };
  return j.keys;
}

export async function verifyIdToken(token, projectId, now = Date.now() / 1000) {
  const [h, p, s] = String(token).split(".");
  if (!h || !p || !s) throw new Error("bad token");
  const header = JSON.parse(new TextDecoder().decode(fromB64u(h)));
  const payload = JSON.parse(new TextDecoder().decode(fromB64u(p)));
  if (header.alg !== "RS256") throw new Error("alg");
  const jwk = (await getJwks()).find((k) => k.kid === header.kid);
  if (!jwk) throw new Error("kid");
  const key = await crypto.subtle.importKey("jwk", jwk, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
  const ok = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, fromB64u(s), enc.encode(h + "." + p));
  if (!ok) throw new Error("signature");
  if (payload.aud !== projectId || payload.iss !== "https://securetoken.google.com/" + projectId) throw new Error("claims");
  if (!payload.exp || payload.exp < now) throw new Error("expired");
  return payload;
}

let tokenCache = null;
async function getAccessToken(sa) {
  if (tokenCache && tokenCache.exp > Date.now() + 60e3) return tokenCache.token;
  const iat = Math.floor(Date.now() / 1000);
  const head = b64u(enc.encode(JSON.stringify({ alg: "RS256", typ: "JWT" })));
  const claim = b64u(enc.encode(JSON.stringify({
    iss: sa.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: sa.token_uri || "https://oauth2.googleapis.com/token", iat, exp: iat + 3600,
  })));
  const der = Uint8Array.from(atob(sa.private_key.replace(/-----[^-]+-----/g, "").replace(/\s+/g, "")), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey("pkcs8", der, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, enc.encode(head + "." + claim));
  const assertion = head + "." + claim + "." + b64u(sig);
  const r = await fetch(sa.token_uri || "https://oauth2.googleapis.com/token", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=" + assertion,
  });
  const j = await r.json();
  if (!j.access_token) throw new Error("oauth failed");
  tokenCache = { token: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 };
  return j.access_token;
}

export async function handle(request, env) {
  if (request.method === "OPTIONS") return new Response(null, { headers: CORS });
  if (request.method !== "POST") return json({ error: "method" }, 405);
  let sa;
  try { sa = JSON.parse(env.SERVICE_ACCOUNT); } catch (e) { return json({ error: "config" }, 500); }
  let body;
  try { body = await request.json(); } catch (e) { return json({ error: "json" }, 400); }
  let payload;
  try { payload = await verifyIdToken(body.idToken, sa.project_id); } catch (e) { return json({ error: "unauthorized" }, 401); }
  const admins = String(env.ADMIN_EMAILS || "").toLowerCase().split(",").map((x) => x.trim()).filter(Boolean);
  if (!payload.email || !admins.includes(String(payload.email).toLowerCase())) return json({ error: "forbidden" }, 403);

  const tokens = (Array.isArray(body.tokens) ? body.tokens : []).filter((t) => typeof t === "string").slice(0, 50);
  const title = String(body.title || "My Seet").slice(0, 80), text = String(body.body || "").slice(0, 200);
  if (!tokens.length) return json({ sent: 0, failed: 0 });
  const access = await getAccessToken(sa);
  let sent = 0, failed = 0;
  await Promise.all(tokens.map(async (token) => {
    const r = await fetch("https://fcm.googleapis.com/v1/projects/" + sa.project_id + "/messages:send", {
      method: "POST", headers: { Authorization: "Bearer " + access, "Content-Type": "application/json" },
      body: JSON.stringify({ message: { token, notification: { title, body: text },
        android: { priority: "HIGH", notification: { sound: "default", channel_id: "reports" } },
        apns: { payload: { aps: { sound: "default" } } } } }),
    });
    r.ok ? sent++ : failed++;
  }));
  return json({ sent, failed });
}

export default { fetch: (request, env) => handle(request, env) };
