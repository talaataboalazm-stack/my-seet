// يرسل إشعارًا (بصوت) لجوال العميل فور إنشاء تقرير أو زيارة جديدة له.
const {onDocumentCreated} = require("firebase-functions/v2/firestore");
const {initializeApp} = require("firebase-admin/app");
const {getFirestore} = require("firebase-admin/firestore");
const {getMessaging} = require("firebase-admin/messaging");
initializeApp();

exports.notifyClient = onDocumentCreated("clients/{uid}/notes/{noteId}", async (event) => {
  const note = event.data && event.data.data();
  if (!note) return;
  const db = getFirestore();
  const tokensSnap = await db.collection("clients").doc(event.params.uid).collection("tokens").get();
  const tokens = tokensSnap.docs.map((d) => d.id);
  if (!tokens.length) return;

  const isVisit = note.kind === "visit";
  const title = "My Seet";
  const body = isVisit
    ? "تم تحديد موعد زيارة جديدة / A new visit has been scheduled"
    : "تقرير زيارة جديد من صيت / New visit report from SEET";

  const res = await getMessaging().sendEachForMulticast({
    tokens,
    notification: {title, body},
    data: {kind: note.kind || "report"},
    android: {priority: "high", notification: {sound: "default", channelId: "reports"}},
    apns: {payload: {aps: {sound: "default"}}},
  });

  // احذف الرموز غير الصالحة
  const dead = [];
  res.responses.forEach((r, i) => {
    const c = r.error && r.error.code;
    if (c === "messaging/registration-token-not-registered" || c === "messaging/invalid-registration-token") dead.push(tokens[i]);
  });
  await Promise.all(dead.map((t) => db.collection("clients").doc(event.params.uid).collection("tokens").doc(t).delete()));
});
