// وضع تجريبي: البيانات في متصفح الجهاز فقط (بدون خادم).
export const mode="demo";
const KEY="myseet_demo_v2", SES="myseet_demo_session";
const SEED={
 clients:{demo:{id:"demo",username:"demo",pass:"1234",name:{ar:"مطعم الواحة (مثال)",en:"Al Waha Restaurant (sample)"},reportCount:3},
          villa:{id:"villa",username:"villa",pass:"1234",name:{ar:"فيلا النخيل (مثال)",en:"Palm Villa (sample)"},reportCount:1}},
 reports:[
 {id:"r1",c:"demo",date:"2026-10-20",tech:"محمد العتيبي",site:{ar:"المطبخ ومخزن المواد الغذائية",en:"Kitchen and dry store"},pests:["p_roach","p_fly"],mat:"جل صراصير، مبيد رذاذي معتمد",st:"done",notes:"تم الرش والتجييل. لا توجد إصابات نشطة في منطقة التحضير.",next:"2026-11-20"},
 {id:"r2",c:"demo",date:"2026-09-22",tech:"محمد العتيبي",site:{ar:"المطبخ والصالة",en:"Kitchen and dining hall"},pests:["p_roach"],mat:"جل صراصير",st:"followup",notes:"ظهور صراصير قرب غسالة الأطباق. يلزم إصلاح تسريب المياه.",next:"2026-10-20"},
 {id:"r3",c:"demo",date:"2026-08-25",tech:"سعد الحربي",site:{ar:"كامل المنشأة",en:"Entire premises"},pests:["p_ant","p_fly"],mat:"مبيد ذباب، طُعم نمل",st:"done",notes:"زيارة دورية بدون ملاحظات.",next:"2026-09-22"},
 {id:"r4",c:"villa",date:"2026-10-15",tech:"سعد الحربي",site:{ar:"الحديقة والمدخل",en:"Garden and entrance"},pests:["p_term"],mat:"معالجة تربة",st:"done",notes:"تمت معالجة محيط الفيلا. المتابعة بعد 30 يومًا.",next:"2026-11-14"}],
 visits:[{id:"v1",c:"demo",date:"2026-11-20",note:""},{id:"v2",c:"villa",date:"2026-11-14",note:""}],
 notes:[{id:"n0",c:"demo",r:"r1",ts:"2026-10-20T11:05:00",read:true},{id:"n00",c:"villa",r:"r4",ts:"2026-10-15T10:00:00",read:true}]
};
const ADMIN={user:"admin",pass:"Seet@2026"};
function load(){try{const v=JSON.parse(localStorage.getItem(KEY));if(v)return v}catch(e){}return JSON.parse(JSON.stringify(SEED))}
let db=load(), authCb=null, dataCb=null, sess=null;
function save(){try{localStorage.setItem(KEY,JSON.stringify(db))}catch(e){}}
function setSess(s){sess=s;try{s?localStorage.setItem(SES,JSON.stringify(s)):localStorage.removeItem(SES)}catch(e){}authCb&&authCb(s)}
function push(){if(!dataCb||!sess)return;
  if(sess.role==="admin"){const cl={};Object.values(db.clients).forEach(c=>cl[c.id]={id:c.id,username:c.username,name:c.name,reportCount:db.reports.filter(r=>r.c===c.id).length});dataCb({clients:cl,reports:[],visits:[],notes:[]});}
  else{const c=db.clients[sess.uid];dataCb({clients:c?{[c.id]:{id:c.id,username:c.username,name:c.name}}:{},reports:db.reports.filter(r=>r.c===sess.uid),visits:db.visits.filter(r=>r.c===sess.uid),notes:db.notes.filter(r=>r.c===sess.uid)})}}
window.addEventListener("storage",e=>{if(e.key===KEY){db=load();push()}});
export function init(cb){authCb=cb;let s=null;try{s=JSON.parse(localStorage.getItem(SES))}catch(e){}setTimeout(()=>cb(s&&(s.role==="admin"||db.clients[s.uid])?(sess=s):null),0)}
export async function loginClient(u,p){const c=db.clients[u];if(!c||c.pass!==p)throw new Error("bad");setSess({role:"client",uid:c.id})}
export async function loginAdmin(u,p){if(u.toLowerCase()!==ADMIN.user||p!==ADMIN.pass)throw new Error("bad");setSess({role:"admin",uid:"admin"})}
export async function logout(){setSess(null)}
export function watch(s,cb){dataCb=cb;sess=s;push();return()=>{dataCb=null}}
export async function addClient({name,username,password}){if(db.clients[username])throw new Error("exists");db.clients[username]={id:username,username,pass:password,name:{ar:name,en:name},reportCount:0};save();push()}
export async function addReport(r){const id="r"+Date.now();db.reports.push({...r,id});db.notes.push({id:"n"+id,c:r.c,r:id,ts:new Date().toISOString().slice(0,19),read:false});save();push()}
export async function addVisit(v){const id="v"+Date.now();db.visits.push({...v,id});db.notes.push({id:"n"+id,c:v.c,v:id,ts:new Date().toISOString().slice(0,19),read:false});save();push()}
export async function markRead(id){const n=db.notes.find(x=>x.id===id);if(n&&!n.read){n.read=true;save()}}
export async function saveToken(){}
