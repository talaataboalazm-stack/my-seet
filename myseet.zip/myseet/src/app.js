import {T,C,IMG,LOGO_MARK,LOGO_FULL} from "./data.js";
import {store} from "./store.js";
import {initPush} from "./push.js";

export function startApp(){
var ADMIN_APP=import.meta.env.MODE==="admin";
var IMGS=IMG;
var CONTACT={hot:"920017731",wa:"0578272727",web:"seetpestcontrol.com.sa",mail:"info@seetpestcontrol.com.sa"};
var CLIENTS={};
var S={lang:"ar",view:ADMIN_APP?"admin":"home",user:null,rid:null,admin:false,atab:"clients",visits:[],reports:[],notes:[],err:false,busy:false,ready:false};
try{var lg=localStorage.getItem("myseet_lang");if(lg==="en"||lg==="ar")S.lang=lg}catch(e){}
function saveLang(){try{localStorage.setItem("myseet_lang",S.lang)}catch(e){}}
var unwatch=null;
function markRead(n){n.read=true;store.markRead(n.id,n.c).catch(function(){})}
function t(k){return T[S.lang][k]||k}
function esc(s){return String(s==null?"":s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})}
function fd(d){try{return new Date(d+"T12:00:00").toLocaleDateString(S.lang==="ar"?"ar-SA-u-ca-gregory":"en-GB",{day:"numeric",month:"long",year:"numeric"})}catch(e){return d}}
function ico(n){var p={home:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',svc:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',about:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',contact:'<path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z"/>',acc:'<circle cx="12" cy="8" r="4"/><path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>',bell:'<path d="M6 9a6 6 0 0112 0c0 6 2 7 2 8H4c0-1 2-2 2-8z"/><path d="M10 21h4"/>'};return '<svg viewBox="0 0 24 24" aria-hidden="true">'+p[n]+'</svg>'}
function CC(){return C[S.lang]}
function ul(a){return '<ul class="bl">'+a.map(function(x){return '<li>'+esc(x)+'</li>'}).join("")+'</ul>'}
function det(title,intro,items,sub){return '<details class="d"><summary><span>'+esc(title)+(sub?'<small>'+esc(sub)+'</small>':'')+'</span></summary><div class="db">'+(intro?'<p class="lead">'+esc(intro)+'</p>':'')+ul(items)+'</div></details>'}
function img(k,cls){return '<img class="'+(cls||'')+'" alt="" loading="lazy" src="'+IMGS[k]+'">'}
function secH(txt){return '<div class="sec">'+esc(txt)+'</div>'}
function contactBtns(){var c=CC().ui;return '<div class="row"><a class="btn" href="https://wa.me/966578272727" target="_blank" rel="noopener">'+c.open_wa+'</a><a class="btn line" href="tel:0578272727">'+c.call+'</a><a class="btn line" href="https://seetpestcontrol.com.sa/" target="_blank" rel="noopener">'+c.open_web+'</a></div>'}
function vHome(){
  var c=CC();
  return '<section class="hero"><div class="logo-panel"><img alt="SEET صيت" src="'+LOGO_FULL+'"><p class="tagline">'+esc(c.ui.tag)+'</p></div><h1>'+t("h_title")+'</h1><p>'+t("h_sub")+'</p><div class="row"><button class="btn" data-a="go" data-v="account">'+t("login_cta")+'</button><button class="btn alt" data-a="go" data-v="services">'+t("see_services")+'</button></div></section>'+
  secH(t("how"))+'<div class="card steps"><div class="step"><p>'+t("s1")+'</p></div><div class="step"><p>'+t("s2")+'</p></div><div class="step"><p>'+t("s3")+'</p></div></div>'+
  secH(t("quick"))+'<div class="card">'+copyRow(c.ui.hot,CONTACT.hot)+copyRow(c.ui.wa,CONTACT.wa)+contactBtns()+'</div>';
}
function vServices(){
  var c=CC(),u=c.ui;
  var h='<h2>'+t("services")+'</h2><p class="muted">'+t("services_sub")+'</p>';
  h+=secH(u.progs)+c.progs.map(function(p){return det(p[0],p[1],p[2])}).join("");
  h+=secH(u.types)+'<div class="grid2">'+c.types.map(function(x){return '<div class="card tcard">'+img(x[0],"ph-img")+'<h3>'+esc(x[1])+'</h3><p class="muted">'+esc(x[2])+'</p></div>'}).join("")+'</div>';
  h+=secH(u.pests)+'<div class="card">'+c.groups.map(function(g){return '<div class="pg"><b>'+esc(u[g[0]])+'</b><div class="chips">'+g[1].map(function(x){return '<span class="chip">'+esc(x)+'</span>'}).join("")+'</div></div>'}).join("")+'</div>';
  h+=secH(u.methods)+c.methods.map(function(m){return det(m[0],"",m[2],m[1])}).join("");
  h+=secH(u.harm)+'<div class="card"><p>'+esc(c.harm_intro)+'</p><div class="chips">'+c.diseases.map(function(x){return '<span class="chip">'+esc(x)+'</span>'}).join("")+'</div><p class="muted">'+esc(c.harm_note)+'</p></div>'+c.harm.map(function(p){return det(p[0],p[1],p[2])}).join("");
  h+=secH(u.equip)+'<div class="card"><p>'+esc(c.equip)+'</p></div><div class="grid2"><figure class="fig">'+img("ulv","cap-img")+'<figcaption class="muted">'+esc(c.equip_cap[0])+'</figcaption></figure><figure class="fig">'+img("fog","cap-img")+'<figcaption class="muted">'+esc(c.equip_cap[1])+'</figcaption></figure></div>';
  h+=secH(u.work)+'<div class="gal">'+["vision","walk","hospital","bait","warehouse","quality","plan","pre"].map(function(k){return img(k)}).join("")+'</div>';
  return h;
}
function vAbout(){
  var c=CC(),u=c.ui;
  var h='<h2>'+t("about")+'</h2><div class="card">'+img("warehouse","ph-img wide")+'<p>'+esc(c.about)+'</p><p>'+esc(c.about2)+'</p></div>';
  h+=secH(u.vision)+'<div class="card"><p>'+esc(c.vision)+'</p></div>'+secH(u.mission)+'<div class="card"><p>'+esc(c.mission)+'</p></div>';
  h+=secH(u.values)+'<div class="card"><div class="chips">'+c.values.map(function(x){return '<span class="chip">'+esc(x)+'</span>'}).join("")+'</div></div>';
  h+=secH(u.why)+'<div class="card">'+ul(c.why)+'</div>';
  h+=secH(u.plan)+'<p class="muted">'+esc(c.plan_intro)+'</p><div class="card steps">'+c.plan.map(function(s){return '<div class="step"><p><b>'+esc(s[0])+'</b><br>'+esc(s[1])+'</p></div>'}).join("")+'</div>';
  h+=secH(u.quality)+'<div class="card">'+img("quality","ph-img wide")+'<p>'+esc(c.quality)+'</p><h3>'+esc(u.commit)+'</h3><div class="chips">'+c.tags.map(function(x){return '<span class="chip">'+esc(x)+'</span>'}).join("")+'</div><p>'+esc(c.commit)+'</p></div>';
  h+=secH(u.clients)+'<div class="logos">'+IMGS.logos.map(function(s){return '<img alt="" loading="lazy" src="'+s+'">'}).join("")+'</div>';
  h+=secH(u.info)+'<div class="card">'+kv(u.hot,'<span dir="ltr">'+CONTACT.hot+'</span>')+kv(u.cr,'<span dir="ltr">1010826647</span>')+kv(u.tax,'<span dir="ltr">311444952700003</span>')+kv(u.addr,esc(u.addr_v))+'</div>';
  h+='<p class="quote">'+esc(c.closing)+'</p>';
  return h;
}
function vContact(){
  var c=CC(),u=c.ui;
  return '<h2>'+t("contact")+'</h2><div class="card">'+copyRow(u.hot,CONTACT.hot)+copyRow(u.wa,CONTACT.wa)+copyRow(u.web,CONTACT.web)+copyRow(u.email,CONTACT.mail)+kv(u.addr,esc(u.addr_v))+contactBtns()+'<div class="row"><a class="btn line" href="https://maps.app.goo.gl/iSDMqciaeJegtWMz7?g_st=awb" target="_blank" rel="noopener">'+u.open_map+'</a></div></div>'+
  secH(t("req"))+'<form class="card" id="reqf"><label for="qn">'+t("f_name")+'<input id="qn" required></label><label for="qp">'+t("f_phone")+'<input id="qp" inputmode="tel" dir="ltr" required></label><label for="qm">'+t("f_msg")+'<textarea id="qm"></textarea></label><button class="btn" type="submit">'+t("send")+'</button></form>';
}

function myNotes(){return S.notes.filter(function(n){return n.c===S.user}).sort(function(a,b){return b.ts.localeCompare(a.ts)})}
function unread(){return myNotes().filter(function(n){return !n.read}).length}
function go(v,rid){S.view=v;S.rid=rid||null;S.err=false;render();window.scrollTo(0,0)}

function head(){
  var b=S.user&&!ADMIN_APP?'<button class="chip-btn" data-a="notes" aria-label="'+t("notifs")+'">'+ico("bell").replace('<svg','<svg width="20" height="20"')+(unread()?'<span class="dot">'+unread()+'</span>':'')+'</button>':'';
  document.getElementById("top").innerHTML='<div class="brand"><span class="mark"><img alt="" src="'+LOGO_MARK+'"></span>'+t("app")+'</div><div class="tools">'+b+'<button class="chip-btn" data-a="lang" aria-label="Language">'+(S.lang==="ar"?"EN":"ع")+'</button></div>';
}
function nav(){
  if(ADMIN_APP){document.getElementById("nav").style.display="none";return}
  var items=[["home","home","nav_home"],["services","svc","nav_services"],["about","about","nav_about"],["contact","contact","nav_contact"],["account","acc","nav_account"]];
  var cur=S.view; if(["report","notes","admin","alogin"].indexOf(cur)>-1)cur="account";
  document.getElementById("nav").innerHTML='<div class="in">'+items.map(function(i){return '<button data-a="go" data-v="'+i[0]+'"'+(cur===i[0]?' aria-current="page"':'')+'>'+ico(i[1])+'<span>'+t(i[2])+'</span></button>'}).join("")+'</div>';
}
function kv(k,v){return '<div class="kv"><b>'+k+'</b><span>'+v+'</span></div>'}
function pestChips(a){return '<div class="chips">'+a.map(function(p){return '<span class="chip">'+t(p)+'</span>'}).join("")+'</div>'}
function copyRow(k,v){return '<div class="kv"><b>'+k+'</b><span><span dir="ltr">'+esc(v)+'</span> <button class="chip-btn" style="height:30px;min-width:0;padding:0 10px;font-size:12px" data-a="copy" data-v="'+esc(v)+'">'+t("copy")+'</button></span></div>'}

function vLogin(){
  return '<h2>'+t("login")+'</h2><form class="card" id="lf"><label for="lu">'+t("user")+'<input id="lu" autocomplete="username" dir="ltr" required></label><label for="lp">'+t("pass")+'<input id="lp" type="password" autocomplete="current-password" dir="ltr" required></label>'+(S.err?'<p class="badge warn">'+t("bad")+'</p>':'')+'<button class="btn" type="submit">'+t("enter")+'</button></form>'+
  (store.mode==="demo"?'<div class="demo"><b>'+t("demo")+'</b><br>'+t("demo_txt")+'</div>':'');
}
function myVisits(){var today=new Date().toISOString().slice(0,10);return S.visits.filter(function(v){return v.c===S.user&&v.date>=today}).sort(function(a,b){return a.date.localeCompare(b.date)})}
function myReports(){return S.reports.filter(function(r){return r.c===S.user}).sort(function(a,b){return b.date.localeCompare(a.date)})}
function isNew(r){return S.notes.some(function(n){return n.r===r.id&&n.c===S.user&&!n.read})}
function vDash(){
  var rs=myReports(),up=myVisits(),nx=up.length?up[0].date:"";
  var h='<h2>'+t("hello")+'، '+esc(((CLIENTS[S.user]||{}).name||{})[S.lang]||'')+'</h2><div class="grid2"><div class="card"><span class="muted">'+t("next_visit")+'</span><b>'+(nx?fd(nx):"—")+'</b></div><div class="card"><span class="muted">'+t("visits")+'</span><b style="font-size:22px;font-family:var(--display)">'+rs.length+'</b></div></div>';
  h+='<div class="sec">'+t("upcoming")+'</div>'+(up.length?'<div class="card">'+up.map(function(v){return kv(fd(v.date),esc(v.note||""))}).join("")+'</div>':'<p class="muted">'+t("no_up")+'</p>')+'<div class="sec">'+t("reports")+'</div>'+rs.map(function(r){return '<button class="rep" data-a="rep" data-v="'+r.id+'"><span class="main"><b>'+fd(r.date)+'</b><span class="muted">'+esc(r.site[S.lang]||r.site.ar||r.site)+'</span></span><span class="row" style="flex-wrap:nowrap;align-items:center">'+(isNew(r)?'<span class="badge new">'+t("new")+'</span>':'')+'<span class="badge '+(r.st==="done"?"good":"warn")+'">'+t(r.st)+'</span></span></button>'}).join("");
  h+='<div class="row"><button class="btn line" data-a="out">'+t("logout")+'</button></div>';
  return h;
}
function vReport(){
  var r=S.reports.filter(function(x){return x.id===S.rid})[0]; if(!r)return vDash();
  S.notes.forEach(function(n){if(n.r===r.id&&n.c===S.user&&!n.read)markRead(n)});
  return '<button class="back" data-a="go" data-v="account">← '+t("back")+'</button><h2>'+fd(r.date)+'</h2><div class="card">'+kv(t("tech"),esc(r.tech))+kv(t("site"),esc(r.site[S.lang]||r.site.ar||r.site))+kv(t("status"),'<span class="badge '+(r.st==="done"?"good":"warn")+'">'+t(r.st)+'</span>')+kv(t("materials"),esc(r.mat))+kv(t("next"),r.next?fd(r.next):"—")+'</div>'+
  '<div class="card"><h3>'+t("pests")+'</h3>'+pestChips(r.pests)+'</div><div class="card"><h3>'+t("notes")+'</h3><p>'+esc(r.notes)+'</p></div><div class="sec">'+t("photos")+'</div><div class="grid2"><div class="ph">'+t("work_ph")+'</div><div class="ph">'+t("work_ph")+'</div></div>';
}
function vNotes(){
  var ns=myNotes();
  var h='<button class="back" data-a="go" data-v="account">← '+t("back")+'</button><h2>'+t("notifs")+'</h2>';
  if(!ns.length)return h+'<p class="muted">'+t("no_notifs")+'</p>';
  return h+ns.map(function(n){if(n.v){var vv=S.visits.filter(function(x){return x.id===n.v})[0];var was=n.read;if(!was)markRead(n);if(!vv)return"";return '<div class="rep"><span class="main"><b>'+t("visit_notif")+'</b><span class="muted">'+fd(vv.date)+'</span></span>'+(was?'':'<span class="badge new">'+t("new")+'</span>')+'</div>'}var r=S.reports.filter(function(x){return x.id===n.r})[0];if(!r)return"";return '<button class="rep" data-a="rep" data-v="'+r.id+'"><span class="main"><b>'+t("new_report")+'</b><span class="muted">'+fd(r.date)+'</span></span>'+(n.read?'':'<span class="badge new">'+t("new")+'</span>')+'</button>'}).join("");
}
function vStaff(){
  var opts=Object.keys(CLIENTS).map(function(k){return '<option value="'+k+'"'+(k===S.user?' selected':'')+'>'+esc(CLIENTS[k].name[S.lang])+'</option>'}).join("");
  var pk=["p_roach","p_ant","p_rodent","p_term","p_fly","p_bed"].map(function(p){return '<label><input type="checkbox" name="pest" value="'+p+'">'+t(p)+'</label>'}).join("");
  var today=new Date().toISOString().slice(0,10);
  return ''+
  '<form class="card" id="sf"><label for="sc">'+t("client")+'<select id="sc">'+opts+'</select></label><label for="sd">'+t("date")+'<input id="sd" type="date" value="'+today+'" required></label><label for="st">'+t("tech")+'<input id="st" required></label><label for="ss">'+t("site")+'<input id="ss" required></label><div class="checks" role="group" aria-label="'+t("pests")+'">'+pk+'</div><label for="sm">'+t("materials")+'<input id="sm"></label><label for="sx">'+t("status")+'<select id="sx"><option value="done">'+t("done")+'</option><option value="followup">'+t("followup")+'</option></select></label><label for="sn">'+t("notes")+'<textarea id="sn"></textarea></label><label for="sy">'+t("next")+'<input id="sy" type="date"></label><button class="btn" type="submit">'+t("publish")+'</button></form>';
}
function clientOpts(){return Object.keys(CLIENTS).map(function(k){return '<option value="'+esc(k)+'">'+esc(CLIENTS[k].name[S.lang]||CLIENTS[k].name.ar)+'</option>'}).join("")}
function vAlogin(){return '<h2>'+t("admin_login")+'</h2><form class="card" id="alf"><label for="au">'+t("admin_user")+(store.mode==="firebase"?" (Email)":"")+'<input id="au" dir="ltr" autocomplete="username" required></label><label for="ap">'+t("pass")+'<input id="ap" type="password" dir="ltr" autocomplete="current-password" required></label>'+(S.err?'<p class="badge warn">'+t("bad")+'</p>':'')+'<button class="btn" type="submit">'+t("enter")+'</button></form>'+(store.mode==="demo"?'<div class="demo"><b>'+t("demo")+'</b><br>'+t("admin_demo")+'</div>':'')}
function vClientsAdmin(){
  var ks=Object.keys(CLIENTS);
  var list=ks.length?ks.map(function(k){var n=S.reports.filter(function(r){return r.c===k}).length;return '<div class="card"><h3>'+esc(CLIENTS[k].name[S.lang]||CLIENTS[k].name.ar)+'</h3>'+kv(t("user"),'<span dir="ltr">'+esc(CLIENTS[k].username||k)+'</span>')+kv(t("reports_n"),CLIENTS[k].reportCount!=null?CLIENTS[k].reportCount:n)+'</div>'}).join(""):'<p class="muted">'+t("no_clients")+'</p>';
  return list+'<div class="sec">'+t("add_client")+'</div><form class="card" id="cf"><label for="cn">'+t("cname")+'<input id="cn" required></label><label for="cu">'+t("set_user")+'<input id="cu" dir="ltr" autocomplete="off" required></label><label for="cp">'+t("set_pass")+'<input id="cp" dir="ltr" autocomplete="off" required></label><button class="btn" type="submit">'+t("add")+'</button></form>';
}
function vVisitForm(){
  return '<form class="card" id="vf"><label for="vc">'+t("client")+'<select id="vc">'+clientOpts()+'</select></label><label for="vd">'+t("visit_date")+'<input id="vd" type="date" required></label><label for="vn">'+t("visit_note")+'<input id="vn"></label><button class="btn" type="submit">'+t("sched")+'</button></form>';
}
function vAdmin(){
  var tabs=[["clients","a_clients"],["report","a_report"],["visit","a_visit"]].map(function(x){var on=S.atab===x[0];return '<button class="chip-btn" data-a="atab" data-v="'+x[0]+'"'+(on?' aria-current="true" style="background:var(--brand);color:var(--brand-ink);border-color:var(--brand)"':'')+'>'+t(x[1])+'</button>'}).join("");
  var h='<div class="row" style="justify-content:space-between;align-items:center"><h2>'+t("admin")+'</h2><button class="chip-btn" data-a="aout">'+t("logout")+'</button></div><p class="muted">'+t("admin_sub")+'</p><div class="row">'+tabs+'</div>';
  if(S.atab==="report")return h+vStaff();
  if(S.atab==="visit")return h+vVisitForm();
  return h+vClientsAdmin();
}
function render(){
  document.documentElement.lang=S.lang;document.documentElement.dir=S.lang==="ar"?"rtl":"ltr";
  var v=S.view,h="";
  if(ADMIN_APP){h=S.admin?vAdmin():vAlogin()}else if(v==="home")h=vHome();else if(v==="services")h=vServices();else if(v==="about")h=vAbout();else if(v==="contact")h=vContact();
  else if(v==="account")h=S.user?vDash():vLogin();else if(v==="report")h=S.user?vReport():vLogin();else if(v==="notes")h=S.user?vNotes():vLogin();
  document.getElementById("app").innerHTML=h;head();nav();saveLang();
}
function toast(title,body,act){
  var el=document.createElement("div");el.className="t";el.innerHTML='<div style="flex:1;min-width:0"><b>'+esc(title)+'</b><div style="opacity:.85;font-size:13.5px">'+esc(body||"")+'</div></div>';
  if(act){el.style.cursor="pointer";el.addEventListener("click",function(){act();el.remove()})}
  document.getElementById("toast").appendChild(el);setTimeout(function(){el.remove()},5000);
}
function beep(){try{var C=window.AudioContext||window.webkitAudioContext,c=new C(),o=c.createOscillator(),g=c.createGain();o.type="sine";o.frequency.value=880;g.gain.setValueAtTime(.0001,c.currentTime);g.gain.exponentialRampToValueAtTime(.25,c.currentTime+.02);g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+.5);o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+.55)}catch(e){}}
document.addEventListener("click",function(e){
  var b=e.target.closest("[data-a]");if(!b)return;var a=b.dataset.a,v=b.dataset.v;
  if(a==="go")go(v);else if(a==="lang"){S.lang=S.lang==="ar"?"en":"ar";render()}
  else if(a==="rep")go("report",v);else if(a==="notes")go("notes");
  else if(a==="out"||a==="aout"){store.logout()}
  else if(a==="atab"){S.atab=v;render()}
  else if(a==="copy"){var done=function(){toast(t("copied"),v)};try{navigator.clipboard.writeText(v).then(done,function(){})}catch(x){}}
});
function val(id){return document.getElementById(id).value}
function fail(err){S.err=true;S.busy=false;render()}
document.addEventListener("submit",function(e){
  e.preventDefault();var f=e.target.id,form=e.target;
  if(S.busy)return;
  if(f==="lf"){S.busy=true;store.loginClient(val("lu").trim().toLowerCase(),val("lp")).then(function(){S.busy=false},fail)}
  else if(f==="alf"){S.busy=true;store.loginAdmin(val("au").trim(),val("ap")).then(function(){S.busy=false},fail)}
  else if(f==="cf"){
    var un=val("cu").trim().toLowerCase().replace(/[^a-z0-9._-]/g,""),nm=val("cn").trim(),pw=val("cp");
    if(!un||pw.length<6){toast(t("c_bad"));return}
    S.busy=true;
    store.addClient({name:nm,username:un,password:pw}).then(function(){S.busy=false;toast(t("c_added"));form.reset()},function(er){S.busy=false;toast(er&&er.message==="exists"?t("c_exists"):t("c_fail"))});
  }
  else if(f==="vf"){
    S.busy=true;
    store.addVisit({c:val("vc"),date:val("vd"),note:val("vn")}).then(function(){S.busy=false;toast(t("vis_sent"));form.reset()},function(){S.busy=false;toast(t("c_fail"))});
  }
  else if(f==="reqf"){toast(t("req_ok"));form.reset()}
  else if(f==="sf"){
    var ps=[].slice.call(document.querySelectorAll('input[name="pest"]:checked')).map(function(x){return x.value});
    var site=val("ss");
    S.busy=true;
    store.addReport({c:val("sc"),date:val("sd"),tech:val("st"),site:{ar:site,en:site},pests:ps,mat:val("sm"),st:val("sx"),notes:val("sn"),next:val("sy")}).then(function(){S.busy=false;toast(t("sent"));form.reset()},function(){S.busy=false;toast(t("c_fail"))});
  }
});

var lastUnread=-1;
function onData(d){
  CLIENTS=d.clients||{};S.reports=d.reports||[];S.visits=d.visits||[];
  var prev=S.notes.length;S.notes=d.notes||[];
  var u=S.user?unread():0;
  if(S.user&&lastUnread>=0&&u>lastUnread&&!(window.__native)){beep();var n=myNotes()[0];toast(t("new_report"),"",function(){go("notes")})}
  lastUnread=S.user?u:-1;
  render();
}
store.init(function(sess){
  if(unwatch){unwatch();unwatch=null}
  S.ready=true;S.busy=false;S.err=false;lastUnread=-1;
  if(!sess){S.user=null;S.admin=false;S.reports=[];S.visits=[];S.notes=[];CLIENTS={};go(ADMIN_APP?"admin":(["home","services","about","contact"].indexOf(S.view)>-1?S.view:"account"));return}
  if(sess.role==="admin"){if(!ADMIN_APP){store.logout();return}S.admin=true;S.user=null;S.atab="clients"}
  else{if(ADMIN_APP){store.logout();return}S.user=sess.uid;S.admin=false;initPush(sess.uid,store,function(title,body){beep();toast(title,body,function(){go("notes")})})}
  unwatch=store.watch(sess,onData);
  go(S.admin?"admin":"account");
});
render();
}
