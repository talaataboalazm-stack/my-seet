import {Capacitor} from "@capacitor/core";
let done=false;
export async function initPush(uid,store,onForeground){
  if(!Capacitor.isNativePlatform()||store.mode!=="firebase")return;
  window.__native=true;
  try{
    const {PushNotifications}=await import("@capacitor/push-notifications");
    if(!done){
      done=true;
      PushNotifications.addListener("registration",t=>store.saveToken(window.__uid,t.value).catch(()=>{}));
      PushNotifications.addListener("pushNotificationReceived",n=>onForeground(n.title||"My Seet",n.body||""));
    }
    window.__uid=uid;
    try{await PushNotifications.createChannel({id:"reports",name:"Reports",importance:5,sound:"default",vibration:true})}catch(e){}
    let p=await PushNotifications.checkPermissions();
    if(p.receive!=="granted")p=await PushNotifications.requestPermissions();
    if(p.receive==="granted")await PushNotifications.register();
  }catch(e){}
}
