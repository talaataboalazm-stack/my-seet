import {firebaseConfig} from "./firebase-config.js";
import * as local from "./store-local.js";
import * as fb from "./store-firebase.js";
export const store = firebaseConfig.apiKey ? fb : local;
