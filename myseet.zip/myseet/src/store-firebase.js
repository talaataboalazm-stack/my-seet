import {initializeApp} from "firebase/app";
import {getAuth,onAuthStateChanged,signInWithEmailAndPassword,signOut,createUserWithEmailAndPassword} from "firebase/auth";
import {getFirestore,doc,getDoc,setDoc,collection,onSnapshot,writeBatch,increment,serverTimestamp,query,orderBy} from "firebase/firestore";
import {firebaseConfig,USERNAME_DOMAIN} from "./firebase-config.js";
export const mode="firebase";
let auth,db;
function boot(){if(auth)return;const app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app)}
const email=u=>u+"@"+USERNAME_DOMAIN;
export function init(cb){
  boot();
  onAuthStateChanged(auth,async user=>{
    if(!user){cb(null);return}
    try{
      const a=await getDoc(doc(db,"admins",user.uid));
      if(a.exists()){cb({role:"admin",uid:user.uid});return}
      const c=await getDoc(doc(db,"clients",user.uid));
      if(c.exists()){cb({role:"client",uid:user.uid});return}
    }catch(e){}
    await signOut(auth);cb(null);
  });
}
export const loginClient=(u,p)=>signInWithEmailAndPassword(auth,email(u),p);
export const loginAdmin=(u,p)=>signInWithEmailAndPassword(auth,u,p);
export const logout=()=>signOut(auth);
export function watch(sess,cb){
  const st={clients:{},reports:[],visits:[],notes:[]};
  const emit=()=>cb({clients:st.clients,reports:st.reports,visits:st.visits,notes:st.notes});
  const un=[];
  if(sess.role==="admin"){
    un.push(onSnapshot(collection(db,"clients"),s=>{st.clients={};s.forEach(d=>{const x=d.data();st.clients[d.id]={id:d.id,username:x.username,name:x.name,reportCount:x.reportCount||0}});emit()}));
  }else{
    const base=["clients",sess.uid];
    un.push(onSnapshot(doc(db,...base),d=>{if(d.exists()){const x=d.data();st.clients={[d.id]:{id:d.id,username:x.username,name:x.name}};emit()}}));
    const sub=(name,key)=>un.push(onSnapshot(collection(db,...base,name),s=>{st[key]=s.docs.map(d=>({...d.data(),id:d.id,c:sess.uid}));emit()}));
    sub("reports","reports");sub("visits","visits");sub("notes","notes");
  }
  return()=>un.forEach(f=>f());
}
export async function addClient({name,username,password}){
  const sec=initializeApp(firebaseConfig,"sec"+Date.now());
  const sa=getAuth(sec);
  try{
    const cred=await createUserWithEmailAndPassword(sa,email(username),password);
    await setDoc(doc(db,"clients",cred.user.uid),{username,name:{ar:name,en:name},reportCount:0,createdAt:serverTimestamp()});
  }catch(e){if(e&&e.code==="auth/email-already-in-use")throw new Error("exists");throw e}
  finally{try{await signOut(sa)}catch(e){}}
}
const nowTs=()=>new Date().toISOString().slice(0,19);
export async function addReport(r){
  const c=r.c,rid=doc(collection(db,"clients",c,"reports")).id,b=writeBatch(db);
  const {c:_,...data}=r;
  b.set(doc(db,"clients",c,"reports",rid),{...data,createdAt:serverTimestamp()});
  b.update(doc(db,"clients",c),{reportCount:increment(1)});
  b.set(doc(db,"clients",c,"notes",rid),{r:rid,ts:nowTs(),read:false,kind:"report",date:r.date});
  await b.commit();
}
export async function addVisit(v){
  const c=v.c,vid=doc(collection(db,"clients",c,"visits")).id,b=writeBatch(db);
  const {c:_,...data}=v;
  b.set(doc(db,"clients",c,"visits",vid),{...data,createdAt:serverTimestamp()});
  b.set(doc(db,"clients",c,"notes","v"+vid),{v:vid,ts:nowTs(),read:false,kind:"visit",date:v.date});
  await b.commit();
}
export async function markRead(id,c){const {updateDoc}=await import("firebase/firestore");await updateDoc(doc(db,"clients",c,"notes",id),{read:true})}
export async function saveToken(uid,token){await setDoc(doc(db,"clients",uid,"tokens",token),{token,ts:serverTimestamp()})}
