export const firebaseConfig = {
  apiKey: "AIzaSyDkGQqDVlXIiAnIvinXzKjS7hVuD-7BwHI",
  authDomain: "my-seet.firebaseapp.com",
  projectId: "my-seet",
  storageBucket: "my-seet.firebasestorage.app",
  messagingSenderId: "470403627879",
  appId: "1:470403627879:web:0f5b6654fa156ae96a4dc2"
};
export const USERNAME_DOMAIN = "myseet.app";
